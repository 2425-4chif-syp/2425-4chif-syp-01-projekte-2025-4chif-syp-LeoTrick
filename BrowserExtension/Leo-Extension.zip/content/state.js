window.MF = window.MF || {};
MF.state = {
  enabled: true,        // Master
  fontEnabled: true,    // Schrift-Zoom
  mode: "off",
  minPx: 16,
  profanityEnabled: true,
  highContrastEnabled: false,  // Hoher Kontrast Modus
  linkClicks: {}
};
